// BONUS: Add another (nested) layout route that adds the <EventNavigation> component above all /events... page components
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import EditEventPage from "./Pages/EditEventPage";
import EventDetailPage, {
  loader as EventDetailLoader,
  action as eventDeleteAction,
} from "./Pages/EventDetailPage";
import EventsPage, { loader as EventLoader } from "./Pages/EventsPage";
import EventsRoot from "./Pages/EventsRoot";
import HomePage from "./Pages/HomePage";
import NewEventPage, { action as newEventAction } from "./Pages/NewEventPage";
import Root from "./Pages/Root";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Root />,
    children: [
      {
        index: true,
        element: <HomePage />,
      },
      {
        path: "events",
        element: <EventsRoot />,
        children: [
          {
            index: true,
            element: <EventsPage />,
            loader: EventLoader,
          },
          {
            path: ":eventId",
            loader: EventDetailLoader,
            id: "event-detail",
            children: [
              {
                index: true,
                element: <EventDetailPage />,
                action: eventDeleteAction,
              },
              {
                path: "edit",
                element: <EditEventPage />,
              },
            ],
          },

          {
            path: "new",
            element: <NewEventPage />,
            action: newEventAction,
          },
        ],
      },
    ],
  },
]);

function App() {
  return <RouterProvider router={router}></RouterProvider>;
}

export default App;
