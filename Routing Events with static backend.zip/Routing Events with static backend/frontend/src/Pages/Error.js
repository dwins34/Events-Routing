import React from "react";
import PageContent from "../components/PageContent";

const Error = () => {
  return (
    <PageContent title="An error occured">Something went wrong.</PageContent>
  );
};

export default Error;
