import React from "react";
import { Outlet } from "react-router-dom";
import MainNavigation from "../components/MainNavigation";

const Root = () => {
  return (
    <>
      <MainNavigation />
      <main>
        <Outlet />
        {/* An <Outlet> should be used in parent route elements to render their child route elements. 
         allows nested UI to show up when child routes are rendered. */}
      </main>
    </>
  );
};

export default Root;
